package com.int221.project.Exeption;

public class ExceptionHandler extends RuntimeException {
    ExceptionResponse.ERROR_CODE errorCode;

    public ExceptionHandler(ExceptionResponse.ERROR_CODE errorCode, String s) {
        super(s);
        this.errorCode = errorCode;
    }

    public ExceptionResponse.ERROR_CODE getErrorCode() {
        return this.errorCode;
    }
}

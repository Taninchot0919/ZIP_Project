package com.int221.project.Exeption;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@AllArgsConstructor
@Getter
@Setter
public class ExceptionResponse {

    public enum ERROR_CODE {
        ALBUM_DATA_NOT_DONE(1000),
        ALBUM_DOES_NOT_EXIST(1001),
        ALBUM_ALREADY_EXIST(1002),
        FILE_DOES_NOT_EXIST(2000),
        FILE_ERROR_OCCURRED(2001),
        DOES_NOT_IMAGE_FILE(3000);
        private int value;

        ERROR_CODE(int value) {
            this.value = value;
        }
    }

    private ERROR_CODE errorCode;
    private String message;
    private LocalDateTime dateTime;
}
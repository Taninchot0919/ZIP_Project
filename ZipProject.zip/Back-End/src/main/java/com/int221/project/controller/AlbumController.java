package com.int221.project.controller;

import com.int221.project.model.Album;
import com.int221.project.service.AlbumService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
public class AlbumController {

    @Autowired
    AlbumService albumService;

    @PostMapping("/add")
    public Album addAlbumWithImage(@RequestPart Album album,
                                   @RequestParam("file") MultipartFile file) {
        return albumService.addAlbumWithImage(album, file);
    }

    @PostMapping("/album")
    public Album addAlbum(@RequestBody Album newAlbum) {
        return albumService.addAlbum(newAlbum);
    }

    @GetMapping("/album")
    public List<Album> getAllAlbum() {
        return albumService.getAllAlbum();
    }

    @PutMapping("/album/{id}")
    public Album editAlbum(@RequestBody Album newAlbum,
                           @PathVariable String id) {
        return albumService.editAlbum(newAlbum, id);
    }

    @PutMapping("/edit/{id}")
    public Album editAlbumWithImage(@RequestParam("file") MultipartFile file,
                                    @RequestPart Album newAlbum,
                                    @PathVariable String id) {
        return albumService.editAlbumWithImage(newAlbum, file, id);
    }

    @GetMapping("/album/{id}")
    public Album findAlbumById(@PathVariable String id) {
        return albumService.findAlbumById(id);
    }

    @DeleteMapping("/album/{id}")
    public void deleteAlbum(@PathVariable String id) {
        albumService.deleteAlbum(id);
    }
    
}

package com.int221.project.controller;

import com.int221.project.service.FileStorageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
public class ImageController {

    @Autowired
    FileStorageService fileStorageService;

    @GetMapping("/image/{filename}")
    public ResponseEntity<byte[]> getImage(@PathVariable String filename) {
        return fileStorageService.getImage(filename);
    }

    @PostMapping("/upload")
    public void saveImage(@RequestParam("file") MultipartFile file) {
        fileStorageService.uploadFile(file);
    }

    @DeleteMapping("/image/{filename}")
    public void delete(@PathVariable String filename) {
        fileStorageService.deleteFile(filename);
    }

}

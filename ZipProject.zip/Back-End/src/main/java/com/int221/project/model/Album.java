package com.int221.project.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "album")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Album {

    @Id
    @Column(name = "a_id")
    private String albumId;

    @Column(name = "album_name")
    private String albumName;

    @Column(name = "price")
    private Double albumPrice;

    @Column(name = "release_date")
    private Date albumReleaseDate;

    @Column(name = "description")
    private String albumDescription;

    @Column(name = "cover_image")
    private String albumCoverImage;

    @ManyToOne
    @JoinColumn(name = "art_id")
    private Artist artists;

    @ManyToOne
    @JoinColumn(name = "at_id")
    private AlbumType albumTypes;

    @ManyToMany
    @JoinTable(name = "album_details",
            joinColumns = @JoinColumn(name = "a_id", insertable = false, updatable = false),
            inverseJoinColumns = @JoinColumn(name = "av_id", insertable = false, updatable = false)
    )
    @Column(insertable = false, updatable = false)
    private List<AlbumVersion> albumVersions = new ArrayList<>();
}

package com.int221.project.model;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "album_version")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AlbumVersion {

    @Id
    @Column(name = "av_id")
    private String albumVersionId;

    @Column(name = "version")
    private String albumVersion;
}

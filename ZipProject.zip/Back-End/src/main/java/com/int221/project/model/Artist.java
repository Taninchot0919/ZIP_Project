package com.int221.project.model;

import lombok.*;

import javax.persistence.*;

@Entity
@Table(name = "artist")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Artist {

    @Id
    @Column(name = "art_id")
    private String artistId;

    @Column(name = "art_name")
    private String artistName;

    @Column(name = "art_type")
    private String artistType;

}

package com.int221.project.repositories;

import com.int221.project.model.Album;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AlbumRepository extends JpaRepository<Album, String> {
    @Query(value = "select MAX(albumId) FROM Album")
    String lastesId();
}

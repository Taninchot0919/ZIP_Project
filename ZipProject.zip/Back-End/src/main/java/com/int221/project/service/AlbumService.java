package com.int221.project.service;

import com.int221.project.Exeption.ExceptionHandler;
import com.int221.project.Exeption.ExceptionResponse;
import com.int221.project.model.Album;
import com.int221.project.repositories.AlbumRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.NoSuchElementException;

@Service
public class AlbumService extends ColumnIDGenerate {
    @Autowired
    AlbumRepository albumRepository;

    @Autowired
    FileStorageService fileStorageService;

    public Album addAlbum(Album newAlbum) {
        List<Album> albumList = albumRepository.findAll();
        Album[] albums = new Album[albumList.size()];
        albumList.toArray(albums);
        for (Album album : albums) {
            if (album.getAlbumName().replaceAll("\\s", "").equals(newAlbum.getAlbumName().replaceAll("\\s", ""))) {
                throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_ALREADY_EXIST, "Album name : " + newAlbum.getAlbumName() + " already exists");
            }
        }
        String latestId = albumRepository.lastesId();
        if (latestId == null) {
            latestId = "al00";
        }
        String newId = tableIdGenerate(latestId);
        newAlbum.setAlbumId(newId);
        if (newAlbum.getAlbumName() == null || newAlbum.getAlbumPrice() == null ||
                newAlbum.getAlbumDescription() == null || newAlbum.getArtists() == null || newAlbum.getAlbumTypes() == null) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DATA_NOT_DONE, "Album data not done");
        }
        newAlbum.setAlbumName(newAlbum.getAlbumName());
        newAlbum.setAlbumPrice(newAlbum.getAlbumPrice());
        newAlbum.setAlbumDescription(newAlbum.getAlbumDescription());
        newAlbum.setAlbumCoverImage("preview.png");
        newAlbum.setArtists(newAlbum.getArtists());
        newAlbum.setAlbumTypes(newAlbum.getAlbumTypes());
        return albumRepository.save(newAlbum);
    }

    public Album addAlbumWithImage(Album newAlbum, MultipartFile albumImage) {
        List<Album> albumList = albumRepository.findAll();
        Album[] albums = new Album[albumList.size()];
        albumList.toArray(albums);
        for (Album album : albums) {
            if (album.getAlbumName().replaceAll("\\s", "").equals(newAlbum.getAlbumName().replaceAll("\\s", ""))) {
                throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_ALREADY_EXIST, "Album name : " + newAlbum.getAlbumName() + " already exists");
            }
        }
        String latestId = albumRepository.lastesId();
        if (latestId == null) {
            latestId = "al00";
        }

        if (newAlbum.getAlbumName() == null || newAlbum.getAlbumPrice() == null ||
                newAlbum.getAlbumDescription() == null || newAlbum.getArtists() == null || newAlbum.getAlbumTypes() == null) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DATA_NOT_DONE, "Album data not done");
        }
        String newId = tableIdGenerate(latestId);
        newAlbum.setAlbumId(newId);
        newAlbum.setAlbumName(newAlbum.getAlbumName());
        newAlbum.setAlbumPrice(newAlbum.getAlbumPrice());
        newAlbum.setAlbumDescription(newAlbum.getAlbumDescription());
        String coverImage = fileStorageService.uploadFile(albumImage, newId);
        newAlbum.setAlbumCoverImage(coverImage);
        newAlbum.setArtists(newAlbum.getArtists());
        newAlbum.setAlbumTypes(newAlbum.getAlbumTypes());
        return albumRepository.save(newAlbum);
    }

    public List<Album> getAllAlbum() {
        return albumRepository.findAll();
    }

    public Album editAlbum(Album newAlbum, String id) {
        try {
            List<Album> albumList = albumRepository.findAll();
            Album[] albums = new Album[albumList.size()];
            albumList.toArray(albums);
            for (Album album : albums) {
                if (album.getAlbumName().replaceAll("\\s", "").equals(newAlbum.getAlbumName().replaceAll("\\s", "")) && !album.getAlbumId().equals(id)) {
                    throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_ALREADY_EXIST, "Album name : " + newAlbum.getAlbumName() + " already exists");
                }
            }

            if (newAlbum.getAlbumName() == null || newAlbum.getAlbumPrice() == null ||
                    newAlbum.getAlbumDescription() == null || newAlbum.getArtists() == null || newAlbum.getAlbumTypes() == null) {
                throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DATA_NOT_DONE, "Album data not done");
            }
            albumRepository.findById(id).map(album -> {
                album.setAlbumName(newAlbum.getAlbumName());
                album.setAlbumPrice(newAlbum.getAlbumPrice());
                album.setAlbumReleaseDate(newAlbum.getAlbumReleaseDate());
                album.setAlbumDescription(newAlbum.getAlbumDescription());
                album.setArtists(newAlbum.getArtists());
                album.setAlbumTypes(newAlbum.getAlbumTypes());
                album.setAlbumVersions(newAlbum.getAlbumVersions());
                return albumRepository.save(album);
            });
            return albumRepository.findById(id).get();
        } catch (NoSuchElementException e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DOES_NOT_EXIST, "Album ID : " + id + " doesn't exists");
        }
    }

    public Album editAlbumWithImage(Album newAlbum, MultipartFile albumImage, String id) {
        try {
            List<Album> albumList = albumRepository.findAll();
            Album[] albums = new Album[albumList.size()];
            albumList.toArray(albums);
            for (Album album : albums) {
                if (album.getAlbumName().replaceAll("\\s", "").equals(newAlbum.getAlbumName().replaceAll("\\s", "")) && !album.getAlbumId().equals(id)) {
                    throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_ALREADY_EXIST, "Album name : " + newAlbum.getAlbumName() + " already exists");
                }
            }
            if (newAlbum.getAlbumName() == null || newAlbum.getAlbumPrice() == null ||
                    newAlbum.getAlbumDescription() == null || newAlbum.getArtists() == null || newAlbum.getAlbumTypes() == null) {
                throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DATA_NOT_DONE, "Album data not done");
            }
            albumRepository.findById(id).map(album -> {
                album.setAlbumName(newAlbum.getAlbumName());
                album.setAlbumPrice(newAlbum.getAlbumPrice());
                album.setAlbumReleaseDate(newAlbum.getAlbumReleaseDate());
                album.setAlbumDescription(newAlbum.getAlbumDescription());
                fileStorageService.deleteFile(album.getAlbumCoverImage());
                String coverImage = fileStorageService.uploadFile(albumImage, id);
                album.setAlbumCoverImage(coverImage);
                album.setArtists(newAlbum.getArtists());
                album.setAlbumTypes(newAlbum.getAlbumTypes());
                album.setAlbumVersions(newAlbum.getAlbumVersions());
                return albumRepository.save(album);
            }).get();
        } catch (NoSuchElementException e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DOES_NOT_EXIST, "Album ID : " + id + " doesn't exists");
        }
        return null;
    }

    public void deleteAlbum(String id) {
        try {
            albumRepository.findById(id).map(album -> {
                fileStorageService.deleteFile(album.getAlbumCoverImage());
                albumRepository.deleteById(id);
                return null;
            });
        } catch (NoSuchElementException e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DOES_NOT_EXIST, "Album ID : " + id + " doesn't exists");
        }
    }

    public Album findAlbumById(String id) {
        try {
            return albumRepository.findById(id).get();
        } catch (Exception e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.ALBUM_DOES_NOT_EXIST, "Album ID : " + id + " doesn't exists");
        }
    }
}

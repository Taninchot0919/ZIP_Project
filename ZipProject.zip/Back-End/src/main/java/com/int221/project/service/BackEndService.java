package com.int221.project.service;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class BackEndService {

    public ResponseEntity getHealth() {
        return ResponseEntity.ok().body("This Service is Healthy");
    }
}

package com.int221.project.service;

import java.text.DecimalFormat;

public class ColumnIDGenerate {
    public String tableIdGenerate(String idType) {
        String[] part = idType.split("(?<=\\D)(?=\\d)");
        int latestId = Integer.parseInt(part[1]);
        DecimalFormat decimalFormat = new DecimalFormat("00");
        String format = decimalFormat.format(latestId + 1);
        String newId = part[0] + format;
        return newId;
    }
}

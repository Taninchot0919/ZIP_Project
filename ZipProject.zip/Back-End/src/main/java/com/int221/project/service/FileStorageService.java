package com.int221.project.service;

import com.int221.project.Exeption.ExceptionHandler;
import com.int221.project.Exeption.ExceptionResponse;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.imageio.ImageIO;
import java.awt.*;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.*;

@Service
public class FileStorageService {
    public String uploadFile(MultipartFile file, String id) {
        try {
            String uploadDir = "./image/";
            if (!Files.exists(Path.of(uploadDir))) {
                Files.createDirectories(Path.of(uploadDir));
            }
            String fileName = file.getOriginalFilename();
            String extension = "." + FilenameUtils.getExtension(fileName);
            Path saveTO = Paths.get(uploadDir + id + extension);
            Files.copy(file.getInputStream(), saveTO, StandardCopyOption.REPLACE_EXISTING);
            return id + extension;
        } catch (IOException e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.FILE_ERROR_OCCURRED, "File Error Occurred");
        }
    }

    public ResponseEntity<byte[]> getImage(String filename) {
        try {
            FileInputStream fileInputStream = new FileInputStream("image" + "/" + filename);
            File directory = new File("image" + "/");
            byte[] image = fileInputStream.readAllBytes();
            fileInputStream.close();
            return ResponseEntity.ok().contentType(MediaType.IMAGE_JPEG).body(image);
        } catch (IOException e) {
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.FILE_DOES_NOT_EXIST, "File Doesn't exists");
        }
    }

    public void deleteFile(String filename) {
        try {
            if (!filename.equals("preview.png")) {
                Files.delete(Path.of("image" + "/" + filename));
            }
        } catch (NoSuchFileException e) {
            e.printStackTrace();
            throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.FILE_DOES_NOT_EXIST, "File Doesn't exists");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void uploadFile(MultipartFile file) {
        try {
            String uploadDir = "./image/";
            if (!Files.exists(Path.of(uploadDir))) {
                Files.createDirectories(Path.of(uploadDir));
            }
            File tempFile = new File(uploadDir, file.getOriginalFilename());
            FileUtils.writeByteArrayToFile(tempFile, file.getBytes());
            Image image = ImageIO.read(tempFile);
            if (image == null) {
                throw new ExceptionHandler(ExceptionResponse.ERROR_CODE.DOES_NOT_IMAGE_FILE,"Does not image file");
            }
            String fileName = file.getOriginalFilename();
            Path saveTO = Paths.get(uploadDir + fileName);
            try {
                try {
                    Files.copy(file.getInputStream(), saveTO, StandardCopyOption.REPLACE_EXISTING);
                } catch (Exception e) {
                    e.printStackTrace();
                    throw new RuntimeException("Error : " + e.getMessage());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

CREATE DATABASE IF NOT EXISTS album_shop;
USE album_shop;

CREATE TABLE `album` (
  `a_id` varchar(5) NOT NULL,
  `album_name` varchar(100) NOT NULL,
  `price` decimal(6,2) NOT NULL,
  `release_date` date NOT NULL,
  `description` varchar(2000) NOT NULL,
  `cover_image` varchar(2000) NOT NULL,
  `art_id` varchar(5) NOT NULL,
  `at_id` varchar(5) NOT NULL
);

INSERT INTO `album` (`a_id`, `album_name`, `price`, `release_date`, `description`, `cover_image`, `art_id`, `at_id`) VALUES
('al01', 'Palette 4th Album', '26.50', '2017-04-21', 'Billboard magazine listed the album at number one on its list of \"Best K-Pop Albums of 2017\".\r\nThe album earned IU a Melon Music Award for Album of the Year, and a nomination for Artist of \r\nthe Year and won Record of the Year (Album) in the 27th Seoul Music Awards. Palette also won \r\n\"Best  Pop Album\" award at the 15th Korean Music Awards.', '96eaee920b895bfcdaa31dfffd7d00ca.jpg', 'art01', 'at03'),
('al02', 'Lilac 5th Album', '22.03', '2021-03-26', 'Singer IU is set to release her 5th full album, Lilac, on March 25, the singer and \r\nher agency confirmed on Thursday, March 4.\r\nIU has been teasing her upcoming album the past week, releasing videos with the captions bylac \r\nand hilac. The final teaser, which revealed the album title, shows IU wearing a simple shirt as\r\nwhite and lilac flowers fall around her.', '201800_1349687.jpeg', 'art01', 'at01'),
('al03', 'COLOR*IZ', '21.34', '2018-10-29', 'Color*Iz is the debut extended play (EP) by South Korean–Japanese girl group Iz*One, \r\na project group formed through the 2018 Mnet reality competition show Produce 48. \r\nThe album was released on October 29, 2018 by Off the Record Entertainment. It is available \r\nin two versions: Rose and Color, and contains seven tracks (eight for the physical edition) \r\nwith \"La Vie en Rose\" as its lead single.', 'DqhfROlVAAE8BoK.jpg', 'art02', 'at02'),
('al04', 'HEART*IZ', '24.22', '2019-04-01', 'A comeback showcase, entitled \"Heart To\", was held at the Blue Square on the same day as \r\nthe album is release, where Iz*One performed the songs from the EP for the first time. It was \r\nbroadcast live via Mnet and Stone Music YouTube channel. The group recorded for variety show\r\nIdol Room and was broadcast on JTBC on April 2, 2019.', 'D239osbUcAEaiTf.jpg', 'art02', 'at02'),
('al05', 'BLOOM*IZ', '25.47', '2020-02-17', 'a concept trailer titled \r\nWhen Iz Your Blooming Moment? , was uploaded on the group YouTube channel. Its concept, \r\nfeaturing flowers in full bloom and the members in various states of waking, was called \r\ncolorful and sensual. The group official website was also re-branded. The track listing was \r\nrevealed through the group social media on November 3.', 'EPx3XDrU8AAb9Ey.jpg', 'art02', 'at03'),
('al06', 'Oneiric Diary', '23.75', '2020-06-15', 'Oneiric Diary is the \r\nthird extended play by South Korean–Japanese girl group Iz*One. It was released on June 15, \r\n2020, by Off the Record Entertainment.The album is available in three versions: Diary,\r\nOneiric and 3D, and consists of eight tracks including the lead single, Secret Story of the Swan.', 'EaZn-_VUYAE0hLh.jpg', 'art02', 'at02'),
('al07', 'One-reeler', '25.47', '2020-12-07', 'In early November, \r\nit was announced that Iz*One would be having a comeback before the end of the year.\r\nOn November 17, it was confirmed that the group would release their fourth mini-album One-reeler \r\n/ Act IV on December 7. Group teaser photos and individual photos began to release from November \r\n23 onwards, showing three different concepts titling, The Color of Youth, Becoming One and \r\nStay Bold.', 'EokAty1UwAIUrar.jpg', 'art02', 'at02'),
('al08', 'You never walk alone', '16.53', '2017-02-13', 'You Never Walk Alone is a repackage of BTS second studio album Wings. It was released \r\non February 13, 2017 with Spring Day serving as the album title track.\r\nThe album was the third best-selling album of 2017 in South Korea.As 2020, \r\nthe album has sold more than one million copies alone and with the original edition more than \r\ntwo million copies.', 'Ej1FYi7XYAAS2jj.jpg', 'art03', 'at03'),
('al09', 'Map Of The Soul', '17.04', '2020-02-21', 'In a way, \r\nthe biggest inspiration was the story of the BTS members and the seven years they spent together,\r\nA Ji-hye, one half of graphic designer duo Sparks Edition, said in a recent interview with \r\nThe Korea Herald at their studio in Seoul northern Seongbuk-gu.', 'A7PRsNR.jpg', 'art03', 'at03'),
('al10', 'BE', '19.56', '2020-11-20', 'Be is primarily a pop record, \r\nencompassing hip hop, EDM, and disco genres with elements of synth-pop, neo soul, funk, R&B, \r\n1970s, 1980s, 1990s, and 2010s. Described by BTS as \"a letter of hope\", Be touches upon themes \r\nof comfort, loneliness, anxiety, depression, frustration, restlessness, sadness, hope, connection,\r\nand joy.', 'bts-be.jpg', 'art03', 'at03');

CREATE TABLE `album_details` (
  `av_id` varchar(5) NOT NULL,
  `a_id` varchar(5) NOT NULL
);

INSERT INTO `album_details` (`av_id`, `a_id`) VALUES
('av01', 'al01'),
('av02', 'al01'),
('av03', 'al01'),
('av04', 'al01'),
('av01', 'al02'),
('av02', 'al02'),
('av03', 'al02'),
('av04', 'al02'),
('av01', 'al03'),
('av02', 'al03'),
('av03', 'al03'),
('av04', 'al03'),
('av01', 'al04'),
('av02', 'al04'),
('av03', 'al04'),
('av04', 'al04'),
('av01', 'al05'),
('av02', 'al05'),
('av03', 'al05'),
('av04', 'al05'),
('av01', 'al06'),
('av02', 'al06'),
('av03', 'al06'),
('av04', 'al06'),
('av01', 'al07'),
('av02', 'al07'),
('av03', 'al07'),
('av04', 'al07'),
('av01', 'al08'),
('av02', 'al08'),
('av03', 'al08'),
('av04', 'al08'),
('av01', 'al09'),
('av02', 'al09'),
('av03', 'al09'),
('av04', 'al09'),
('av01', 'al10'),
('av02', 'al10'),
('av03', 'al10'),
('av04', 'al10');



CREATE TABLE `album_type` (
  `at_id` varchar(5) NOT NULL,
  `type` varchar(100) NOT NULL
);



INSERT INTO `album_type` (`at_id`, `type`) VALUES
('at01', 'Single Album'),
('at02', 'Mini Album'),
('at03', 'Full Album');



CREATE TABLE `album_version` (
  `av_id` varchar(5) NOT NULL,
  `version` varchar(100) NOT NULL
);



INSERT INTO `album_version` (`av_id`, `version`) VALUES
('av01', 'Version1'),
('av02', 'Version2'),
('av03', 'Version3'),
('av04', 'Version4');



CREATE TABLE `artist` (
  `art_id` varchar(5) NOT NULL,
  `art_name` varchar(100) NOT NULL,
  `art_type` varchar(100) NOT NULL
);

INSERT INTO `artist` (`art_id`, `art_name`, `art_type`) VALUES
('art01', 'IU', 'solo'),
('art02', 'IZ*ONE', 'group'),
('art03', 'BTS', 'group');


ALTER TABLE `album`
  ADD PRIMARY KEY (`a_id`),
  ADD KEY `album_album_type_fk` (`at_id`),
  ADD KEY `album_artist_fk` (`art_id`);

ALTER TABLE `album_details`
  ADD PRIMARY KEY (`av_id`,`a_id`),
  ADD KEY `album_fk` (`a_id`);


ALTER TABLE `album_type`
  ADD PRIMARY KEY (`at_id`);


ALTER TABLE `album_version`
  ADD PRIMARY KEY (`av_id`);


ALTER TABLE `artist`
  ADD PRIMARY KEY (`art_id`);

ALTER TABLE `album`
  ADD CONSTRAINT `album_album_type_fk` FOREIGN KEY (`at_id`) REFERENCES `album_type` (`at_id`),
  ADD CONSTRAINT `album_artist_fk` FOREIGN KEY (`art_id`) REFERENCES `artist` (`art_id`);

ALTER TABLE `album_details`
  ADD CONSTRAINT `album_fk` FOREIGN KEY (`a_id`) REFERENCES `album` (`a_id`),
  ADD CONSTRAINT `album_version_fk` FOREIGN KEY (`av_id`) REFERENCES `album_version` (`av_id`);
COMMIT;

Create USER 'int221AlbumUser'@'%' identified by 'int221101638';
grant insert, update, delete on album to 'int221AlbumUser'@'%';
grant insert, update, delete on album_details to 'int221AlbumUser'@'%';
grant select on  *.* to 'int221AlbumUser'@'%';
FLUSH PRIVILEGES;
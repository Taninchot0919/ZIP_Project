<template>
  <div class="">
    <Navbar class="hidden md:block"/>
    <NavbarV2 class="md:hidden"/>
    <router-view class="pb-20 mt-12 md:mt-0 flex-col pt-16 md:left-64 lg:left-72 absolute px-10 w-full md:w-9/12" id="router-view"/>
  </div>
</template>
<script>
import Navbar from "@/components/Navbar.vue";
import NavbarV2 from "@/components/NavbarV2.vue";

export default {
  name: "App",
  components: {
    Navbar, NavbarV2,
  },
};
</script>

<style >
#title {
  color: #343a47;
}
/* deow ma kae */
body {
  background-image: url("./assets/bg.png");
  background-attachment: fixed;
  background-repeat: no-repeat;
  background-size: cover;
}
</style>

<template>
  <div class="text-gray-800 w-full">
    <div class="font-bold text-5xl px-6 title" id="title">Add Product</div>
    <div
      class="lg:flex lg:justify-center lg:mx-auto px-3 max-w-screen-md w-full mb-20"
    >
      <form @submit.prevent="postFile">
        <div
          class="container md:max-w-screen-md p-8 mx-auto -px-20 mt-12 shadow-lg rounded-lg bg-white grid grid-cols-1 md:grid-cols-2 gap-4"
        >
          <div class="flex-row inline-flex">
            <div class="font-bold lg:text-xl text-gray-700 inline my-auto">Artist :</div>
            <svg
              class="w-2 h-2 absolute mt-4 md:mt-10 ml-44 inline-flex pointer-events-none"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 412 232"
            >
              <path
                d="M206 171.144L42.678 7.822c-9.763-9.763-25.592-9.763-35.355 0-9.763 9.764-9.763 25.592 0 35.355l181 181c4.88 4.882 11.279 7.323 17.677 7.323s12.796-2.441 17.678-7.322l181-181c9.763-9.764 9.763-25.592 0-35.355-9.763-9.763-25.592-9.763-35.355 0L206 171.144z"
                fill="#648299"
                fill-rule="nonzero"
              />
            </svg>
            <select
              @input="validate.artist = false"
              v-model="artists"
              class="border my-auto border-gray-300 rounded-lg text-gray-600 h-10 pl-5 pr-10 ml-5 bg-white w-32 inline-flex hover:border-gray-400 hover:shadow-lg focus:outline-none focus:shadow-lg appearance-none"
            >
              <!-- Artist lists -->
              <option value="" disabled selected hidden>Select</option>
              <option value="art01">IU</option>
              <option value="art02">IZ*ONE</option>
              <option value="art03">BTS</option>
            </select>
            <span v-if="validate.artist" class="text-red-400">
              * Please field
            </span>
          </div>

          <!--add album -->

          <div class="flex flex-col">
            <label for="name" class="text-sm leading-7 text-gray-600"
              >Album Name
              <span v-if="validate.albumName" class="text-red-400"
                >* Please field
              </span></label
            >
            <input
              @input="validate.albumName = false"
              maxlength="100"
              type="text"
              id="name"
              placeholder="Text here"
              v-model="albumName"
              name="name"
              class="bg-gray-100 rounded px-4 py-2 mb-4 w-48 hover:shadow-lg focus:shadow-lg"
            />
          </div>

          <div class="flex flex-col my-2">
            <label for="message" class="text-sm leading-7 text-gray-600"
              >Album cover</label
            >
            <!-- Album Cover Preview -->
            <div
              class="imagePreviewWrapper rounded-lg mx-auto shadow-lg bg-gray-100"
              :style="{ 'background-image': `url(${previewImage})` }"
              @click="selectImage"
            ></div>

            <!-- Album Cover Upload -->
            <input
              ref="fileInput"
              id="file"
              type="file"
              @input="pickFile"
              accept="image/*"
              class="p-1.5 mt-4 w-full rounded-lg text-white"
              style="background-color: #444d61"
            />
          </div>

          <div class="field flex-col textarea">
            <label for="message" class="text-sm leading-7 text-gray-600"
              >Description
              <span v-if="validate.description" class="text-red-400"
                >* Please field
              </span></label
            ><br />
            <textarea
              @input="validate.description = false"
              maxlength="2000"
              v-model="albumDescription"
              cols="38"
              rows="12"
              placeholder="Text here"
              class="bg-gray-100 rounded px-4 py-2 mb-7 resize-none hover:shadow-lg focus:shadow-lg w-full"
            ></textarea>
          </div>

          <div class="flex flex-col">
            <label
              for="type"
              class="text-sm leading-7 text-gray-600 relative inline-flex"
              >Album type
              <span v-if="validate.albumType" class="text-red-400"
                >* Please field
              </span></label
            >
            <div class="relative inline-flex">
              <svg
                class="w-2 h-2 absolute top-0 left-28 m-4 pointer-events-none"
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 412 232"
              >
                <path
                  d="M206 171.144L42.678 7.822c-9.763-9.763-25.592-9.763-35.355 0-9.763 9.764-9.763 25.592 0 35.355l181 181c4.88 4.882 11.279 7.323 17.677 7.323s12.796-2.441 17.678-7.322l181-181c9.763-9.764 9.763-25.592 0-35.355-9.763-9.763-25.592-9.763-35.355 0L206 171.144z"
                  fill="#648299"
                  fill-rule="nonzero"
                />
              </svg>
              <select
                @input="validate.albumType = false"
                v-model="albumTypes"
                class="border border-gray-300 rounded-lg text-gray-600 h-10 pl-5 pr-10 w-40 mb-7 bg-white hover:border-gray-400 hover:shadow-lg focus:outline-none focus:shadow-lg appearance-none"
              >
                <!-- Album type -->
                <option value="" disabled selected hidden>Select</option>
                <option value="at01">Single Album</option>
                <option value="at02">Mini Album</option>
                <option value="at03">Full Album</option>
              </select>
            </div>
          </div>

          <div class="flex flex-col">
            <label
              for="type"
              class="text-sm leading-7 text-gray-600 relative inline-flex pb-3"
              >Album Version
              <span v-if="validate.version" class="text-red-400"
                >* Please field
              </span></label
            >
            <div
              class="relative flex-wrap sm:inline-flex space-x-3 text-sm text-gray-500"
            >
              <div v-for="version in versions" :key="version">
                <input
                  @input="validate.version = false"
                  type="checkbox"
                  :value="version"
                  v-model="albumVersions"
                  class="my-2"
                />
                <span> {{ version.albumVersion }} </span>
              </div>
            </div>
          </div>
          <div class="flex flex-col">
            <label for="date" class="text-sm leading-7 text-gray-600"
              >Release-Date
              <span v-if="validate.date" class="text-red-400"
                >* Please field
              </span></label
            >
            <input
              @input="validate.date = false"
              type="date"
              id="date"
              v-model="albumReleaseDate"
              placeholder="MM/DD/YYYY"
              name="date"
              class="bg-gray-100 rounded px-4 py-2 mb-4 w-44 hover:shadow-lg focus:shadow-lg"
            />
          </div>

          <div class="flex flex-col">
            <label for="price" class="text-sm leading-7 text-gray-600"
              >Price
              <span v-if="validate.price" class="text-red-400"
                >* Please field
              </span>
              <span v-if="validate.priceMax" class="text-red-400"
                >* Price can be 0 - 9999.99
              </span>
            </label>
            <input
              @input="validatePrice"
              step="any"
              min="0"
              max="9999.99"
              type="number"
              id="price"
              v-model="albumPrice"
              maxlength="7"
              placeholder="$"
              name="price"
              class="bg-gray-100 rounded px-4 py-2 mb-7 w-4/12 hover:shadow-lg focus:shadow-lg"
            />
          </div>
          <div />
          <div class="flex justify-center space-x-3">
            <div>
              <button
                id="cbutton"
                @click="goBack"
                class="px-6 py-2 rounded-lg focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
              >
                Cancel
              </button>
            </div>
            <div>
              <input
                id="addbutton"
                type="submit"
                value="Submit"
                class="px-7 py-2 text-white rounded-lg float-right focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
              />
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "AddProduct",
  data() {
    return {
      previewImage: null,
      selectedImage: null,
      albumName: "",
      albumPrice: "",
      albumReleaseDate: "",
      albumDescription: "",
      artists: "",
      albumTypes: "",
      albumVersions: [],
      validate: {
        artist: false,
        albumName: false,
        description: false,
        albumType: false,
        version: false,
        date: false,
        price: false,
        priceMax: false,
      },
      versions: [
        {
          albumVersionId: "av01",
          albumVersion: "Version1",
        },
        {
          albumVersionId: "av02",
          albumVersion: "Version2",
        },
        {
          albumVersionId: "av03",
          albumVersion: "Version3",
        },
        {
          albumVersionId: "av04",
          albumVersion: "Version4",
        },
      ],
    };
  },
  methods: {
    goBack() {
      this.$router.push({ name: "Product" });
    },
    selectImage() {
      this.$refs.fileInput.click();
    },
    validatePrice() {
      (this.validate.price = false), (this.validate.priceMax = false);
    },
    async postFile() {
      let objectType = { albumTypeId: this.albumTypes };
      let objectArtist = { artistId: this.artists };
      let album = {
        albumName: this.albumName,
        albumPrice: this.albumPrice,
        albumReleaseDate: this.albumReleaseDate,
        albumDescription: this.albumDescription,
        artists: objectArtist,
        albumTypes: objectType,
        albumVersions: this.albumVersions,
      };
      if (this.albumName == "") {
        this.validate.albumName = true;
      }
      if (this.albumPrice == "") {
        this.validate.price = true;
      }
      if (this.albumReleaseDate == "") {
        this.validate.date = true;
      }
      if (this.albumDescription == "") {
        this.validate.description = true;
      }
      if (this.artists == "") {
        this.validate.artist = true;
      }
      if (this.albumTypes == "") {
        this.validate.albumType = true;
      }
      if (this.albumVersions == "") {
        this.validate.version = true;
      }
      if (this.albumPrice < 0 || this.albumPrice > 9999.99) {
        this.validate.priceMax = true;
      }
      if (
        this.validate.artist ||
        this.validate.albumName ||
        this.validate.description ||
        this.validate.albumType ||
        this.validate.version ||
        this.validate.date ||
        this.validate.price ||
        this.validate.priceMax
      ) {
        alert("Please field all form");
      } else {
        let response;
        const jsonNewAlbum = JSON.stringify(album);
        if (this.selectedImage == null) {
          response = await fetch("http://168.63.232.208/backend/album", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: jsonNewAlbum,
          });
        } else {
          const blob = new Blob([jsonNewAlbum], {
            type: "application/json",
          });
          const formData = new FormData();
          formData.append("album", blob);
          formData.append("file", this.selectedImage, this.selectedImage.name);
          response = await fetch("http://168.63.232.208/backend/add", {
            method: "POST",
            body: formData,
          });
        }
        // Check Error if error occur it will alert
        if (response.ok) {
          this.$router.push({ name: "Product" });
        } else if (!response.ok) {
          response.text().then((message) => {
            alert(JSON.parse(message).message);
          });
        }
      }
    },
    pickFile(event) {
      let input = this.$refs.fileInput;
      let file = input.files;
      if (file && file[0]) {
        let reader = new FileReader();
        reader.onload = (e) => {
          this.previewImage = e.target.result;
          resizeTo(e.target.result, 127);
        };
        reader.readAsDataURL(file[0]);
        this.$emit("input", file[0]);
      }
      this.selectedImage = event.target.files[0];
    },
    test() {
      this.validate.albumName = false;
    },
  },
};
</script>

<style>
.dropdown:focus-within .dropdown-menu {
  opacity: 1;
  transform: translate(0) scale(1);
  visibility: visible;
}
.imagePreviewWrapper {
  width: 180px;
  height: 180px;
  cursor: pointer;
  background-size: cover;
  background-position: center center;
}
@media (min-width: 445px) {
  .imagePreviewWrapper {
    width: 250px;
    height: 250px;
  }
}
#addbutton {
  background-color: #ffd600;
  color: #ffffff;
}
#addbutton:hover {
  background-color: #e4c000;
  color: #ffffff;
}
@media (min-width: 1650px) {
  .title {
    margin-left: 160px;
  }
}
</style>

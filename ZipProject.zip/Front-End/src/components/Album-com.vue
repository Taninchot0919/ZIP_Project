<template>
  <div
    class="album p-2.5 rounded-lg w-full mt-10 bg-white shadow-xl border border-gray-50 cursor-pointer"
    @click="link"
    id="box"
  >
    <!-- Album cover -->
    <img
      :src="img"
      class="img object-cover h-auto w-full rounded-lg shadow-md mb-5"
    />
    <div class="-mt-2">
      <!-- Album name   -->
      <div class="albumname font-semibold text-gray-800">{{ album.albumName }}</div>
      <!-- Album type -->
      <div class="text-gray-400">{{ album.albumTypes.albumType }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AlbumObject",
  props: ["album"],
  data() {
    return {
      img: ""
    };
  },
  methods: {
    link() {
      this.$router.push({
        name: "Preview",
        params: { albumId: this.album.albumId }
      });
    }
  },
  mounted() {
    this.img = "http://168.63.232.208/backend/image/" + this.album.albumCoverImage;
  }
};
</script>
<style scoped>
#box {
  transition: 0.5s;
}
#box:hover {
  transform: scale(1.1);
  z-index: 1;
  background-color: #fafafa;
}

.album {
  width: 175px;
  height: 235px;
}
.albumname {
  white-space: nowrap;
  width: 155px;
  overflow: hidden;
  text-overflow: ellipsis;
}
.img {
  width: 153px;
  height: 153px;
}
</style>
<template>
  <!-- Artist Name  -->
  <div
    class="p-2.5 rounded-lg mt-10 px-3 w-full shadow-xl flex flex-col text-center"
    id="banner"
  >
    <slot></slot>
  </div>
</template>
<script>
export default {
  name: "ArtistBanner",
};
</script>
<style>
#banner {
  background-color: #343a47;
  color: #ffffff;
}
</style>

<template>
  <div>
    <div class="font-bold text-5xl px-6 mb-12" id="title">Founders</div>
    <div class="flex flex-col w-full space-y-12 ">
      <div
        class="mx-auto w-4/5 md:w-9/12 bg-white rounded-xl shadow-md overflow-hidden "
      >
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img
              class="h-full w-full object-cover md:w-48"
              src="../assets/karn.jpg"
            />
          </div>
          <div class="p-8">
            <a
              href="#"
              class="block mt-1 text-lg leading-tight font-semibold text-black"
            >
              “Without Google I wouldn't be successful in INT221.”</a
            >
            <p class="mt-9 text-cyan-6000 font-medium">62130500010 Karnkamol</p>
            <p class="mt-2 text-gray-500 font-medium">Database, Front-End</p>
          </div>
        </div>
      </div>

      <div
        class="mx-auto w-4/5 md:w-9/12 bg-white rounded-xl shadow-md overflow-hidden"
      >
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img
              class="h-full w-full object-cover md:w-48"
              src="../assets/guy.jpg"
            />
          </div>
          <div class="p-8">
            <a
              href="#"
              class="block mt-1 text-lg leading-tight font-semibold text-black"
            >
              “My computer screen is brighter than my future.”</a
            >
            <p class="mt-9 text-cyan-6000 font-medium">62130500016 Jiraphat</p>
            <p class="mt-2 text-gray-500 font-medium">Front-End, Database</p>
          </div>
        </div>
      </div>

      <div
        class="mx-auto w-4/5 md:w-9/12 bg-white rounded-xl shadow-md overflow-hidden"
      >
        <div class="md:flex">
          <div class="md:flex-shrink-0">
            <img
              class="h-full w-full object-cover md:w-48"
              src="../assets/art.jpg"
            />
          </div>
          <div class="p-8">
            <a
              href="#"
              class="block mt-1 text-lg leading-tight font-semibold text-black"
            >
              "I don't need a piece of paper saying I succeeded. I just need
              food."</a
            >
            <p class="mt-9 text-cyan-6000 font-medium">62130500038 Taninchot</p>
            <p class="mt-2 text-gray-500 font-medium">Back-End, Dev-ops</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Founders",
};
</script>

<template>
  <div class=" ">
    <div class="font-bold text-5xl px-6" id="title">Home</div>
    <div class="flex flex-col items-center justify-center space-y-5">
      <div
        id="info"
        class="w-full md:w-4/5 p-8 rounded-lg mt-10 shadow-xl text-white"
      >
        <div class="font-semibold italic text-base sm:text-3xl text-center">
          118 Music Ent. Info
        </div>
        <div class="flex flex-col justify-center">
          <img src="../assets/logo1.png" class="my-16 " />
          <span class="text-sm sm:text-base">
            118 Music Entertainment is a entertainment company established
            2011.<br />
            As of that date, the company manages soloist IU, boy group BTS and
            girl group IZ*ONE.
          </span>
        </div>
      </div>
      <div class="w-full md:w-4/5 p-8 rounded-lg mt-10 bg-pink-300 shadow-xl">
        <div class="text-white italic text-base sm:text-3xl text-center">
          ♫ IU - MMA 2017 멜론뮤직어워드 ♫
        </div>
        <div class="flex justify-center">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/wKzhZkeBirs"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="mt-5 rounded-lg"
            id="video"
          />
        </div>
      </div>
      <div class="w-full md:w-4/5 p-8 rounded-lg mt-10 bg-purple-300 shadow-xl">
        <div class="text-center text-white italic text-base sm:text-3xl">
          ♫ IU(아이유) - Lilac <br />(라일락(Acoustic Ver.))♫
        </div>
        <div class="flex justify-center">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/9UaDpyffNBA"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="mt-5 rounded-lg"
            id="video"
          />
        </div>
      </div>
      <div class="w-full md:w-4/5 p-8 rounded-lg mt-10 bg-blue-900 shadow-xl">
        <div class="text-center text-white italic text-base sm:text-3xl">
          ♫ IZ*ONE(아이즈원) <br />
          at 2020 MAMA All Moments ♫
        </div>
        <div class="flex justify-center">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/ty0OPbx87QQ"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="mt-5 rounded-lg"
            id="video"
          />
        </div>
      </div>
      <div class="w-full md:w-4/5 p-8 rounded-lg mt-10 bg-yellow-700 shadow-xl">
        <div class="text-center text-white italic text-base sm:text-3xl">
          ♫ BTS (방탄소년단) 'Dynamite'<br />
          @ 63rd GRAMMY Awards Show ♫
        </div>
        <div class="flex justify-center">
          <iframe
            width="560"
            height="315"
            src="https://www.youtube.com/embed/jWRMXiHhDjc"
            title="YouTube video player"
            frameborder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
            class="mt-5 rounded-lg"
            id="video"
          />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "HomeContent",
};
</script>
<style>
#info {
  background-color: #4c5364;
;
}
@media (max-width: 480px){
  #video {
    width: 100%;
    height: 150px;
  }
}
@media (min-width: 481px){
  #video {
    width: 100%;
    height: 300px;
  }
}
@media (min-width: 1281px) {
  #video {
    width: 800px;
    height: 450px;
  }
}
</style>
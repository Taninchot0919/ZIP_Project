<template>
  <nav
    id="navbar"
    class="mt-12 ml-12 shadow-2xl w-52 h-96 rounded-lg fixed float-left z-10"
  >
    <div class="pt-12">
      <div class="flex flex-col items-center justify-center space-y-5">
        <img src="@/assets/logo1.png" class="w-40 h-auto mt-5 mb-12" />
        <router-link
          :to="{ name: 'Home' }"
          id="button"
          class="w-32 px-3 py-2 rounded-md text-sm font-medium text-center"
        >
          Home
        </router-link>

        <router-link
          :to="{ name: 'Product' }"
          id="button"
          class="w-32 px-3 py-2 rounded-md text-sm font-medium text-center"
        >
          Product
        </router-link>

        <router-link
          :to="{ name: 'Founder' }"
          id="button"
          class="w-32 px-3 py-2 rounded-md text-sm font-medium text-center"
        >
          Founders
        </router-link>
      </div>
    </div>
  </nav>
</template>
<script>
export default {
  name: "Navbar",
};
</script>
<style>
#navbar a.router-link-exact-active {
  background-color: #ffffff;
  color: #343a47;
  /* box-shadow: 0px 0px 5px #ffffff; */
}
#button {
  background-color: #444d61;
  color: #ffffff;
  transition: color 0.3s ease;
}
#button:hover {
  background-color: #5b667d;
  transition: color 0.3s ease;
}
#navbar {
  background-color: #343a47;
}
</style>
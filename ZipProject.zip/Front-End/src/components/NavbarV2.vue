<template>
  <nav id="navbar" class="shadow-2xl w-full h-16 fixed z-10">
    <div class="inline-flex justify-between w-full">
      <img src="@/assets/logo2.png" class="imagesize p-2.5 my-auto ml-3" />
      <div class="p-5 cursor-pointer burger" @click="isShow = !isShow">
        <i class="fa fa-bars text-white text-lg " aria-hidden="true"/>
      </div>
    </div>

    <div
      v-show="isShow"
      class="menu w-full flex flex-col items-center justify-center -mt-2"
    >
      <router-link
        :to="{ name: 'Home' }"
        id="button"
        class="w-full px-3 py-5 text-base font-medium text-center shadow-md"
        @click="isShow = !isShow"
      >
        Home
      </router-link>

      <router-link
        :to="{ name: 'Product' }"
        id="button"
        class="w-full px-3 py-5 text-base font-medium text-center shadow-md"
        @click="isShow = !isShow"
      >
        Product
      </router-link>

      <router-link
        :to="{ name: 'Founder' }"
        id="button"
        class="w-full px-3 py-5 text-base font-medium text-center shadow-md"
        @click="isShow = !isShow"
      >
        Founders
      </router-link>
    </div>
  </nav>
</template>
<script>
export default {
  name: "NavbarV2",
  data() {
    return {
      isShow: false,
    };
  },
};
</script>
<style>
#navbar {
  transition: width 1s, height 1s;
}
.menu {
  animation-name: fade-in;
  animation-duration: 0.4s;
  animation-iteration-count: 1;
}
@keyframes fade-in {
  from {
    opacity: 0;
    transform: translateY(-10%);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
.burger:hover{
  background-color: #2F3440;
}
.imagesize{
  width: 60px;
  height: 60px;
}
</style>
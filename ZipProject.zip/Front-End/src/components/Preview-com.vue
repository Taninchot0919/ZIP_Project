<template>
  <div class="justify-items-center w-full mb-20 text-gray-800">
    <div class="font-bold text-5xl px-6 title" id="title">Preview</div>
    <div
      class="flex flex-col md:max-w-screen-md p-4 md:p-10 mx-auto mt-12 shadow-lg rounded-lg bg-white"
    >
      <div
        class="w-full justify-items-stretch md:grid md:grid-cols-2 hidden mx-auto"
      >
        <div class="md:flex-row lg:ml-10 xl:m-18">
          <img
            :src="img"
            class="img object-cover rounded-lg shadow-md justify-items-start"
          />
        </div>
        <div class="md:flex-row justify-items-center mt-10 ml-5 flex-col">
          <!-- Album name -->
          <p class="font-bold text-3xl mb-8">{{ albumName }}</p>
          <!-- Type -->
          <p class="font-normal text-2xl -mt-3 text-gray-400 mb-6">
            {{ albumtype }}
          </p>
          <!-- Artist -->
          <p class="font-medium text-3xl my-2l">{{ artists }}</p>
        </div>
      </div>

      <!-- mobile -->
      <div class="w-full justify-items-center flex-col md:hidden mt-2 mx-auto">
        <div class="flex justify-center w-full mx-auto">
          <img :src="img" class="img object-cover rounded-lg shadow-md flex" />
        </div>
        <div class="mx-8">
          <!-- Album name -->
          <p class="text-center font-bold text-3xl mt-8 mb-4">
            {{ albumName }}
          </p>
          <!-- Type -->
          <!-- Artist -->
          <p class="text-center font-medium text-2xl my-2l`">
            {{ artists }}<span class="font-normal"> - </span
            ><span class="font-normal text-xl text-gray-400">
              {{ albumtype }}</span
            >
          </p>
        </div>
      </div>

      <!-- Description -->
      <div class="font-medium text-xl mt-12">Description</div>
      <p class="my-5 text-base">{{ description }}</p>

      <div class="my-5 hidden md:w-full md:block text-base">
        <button
          class="mx-3 border p-3 flex-wrap rounded-full w-1/6 cursor-pointer bg-gray-50 text-center border-none focus:outline-none focus:ring-2 ring-offset-current"
          v-for="albumVersion in albums.albumVersions"
          :key="albumVersion"
        >
          {{ albumVersion.albumVersion }}
        </button>
      </div>

      <!-- mobile -->
      <div
        class="my-5 md:hidden grid grid-cols-2 gap-2 justify-items-center text-base"
      >
        <button
          class="border p-3 flex-wrap rounded-full w-4/6 cursor-pointer bg-gray-50 text-center border-none focus:outline-none focus:ring-2 ring-offset-current"
          v-for="albumVersion in albums.albumVersions"
          :key="albumVersion"
        >
          {{ albumVersion.albumVersion }}
        </button>
      </div>
      <p class="my-5 text-base font-medium">Release date : {{ date }}</p>
      <p class="my-5 text-base font-medium">Price : {{ price }} $</p>

      <div class="md:grid md:grid-cols-2 w-full mt-10">
        <div />
        <div class="flex justify-center">
          <div>
            <button
              @click="edit"
              id="bbutton"
              class="flex-row px-4 py-2 mx-1.5 my-1 lg:ml-24 xl:ml-28 rounded-lg focus:shadow-outline text-base focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
            >
              Edit Album
            </button>
          </div>
          <div>
            <button
              @click="isShow = !isShow"
              id="bbutton"
              class="flex-row px-4 py-2 mx-1.5 my-1 rounded-lg text-base focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
            >
              Delete
            </button>
          </div>
        </div>
      </div>
    </div>
    <div id="confirm" class="flex justify-center" v-show="isShow">
      <div
        class="shadow-lg rounded-lg bg-white w-full md:w-3/6 h-auto p-5 mx-5 md:mx-auto my-auto space-y-5 flex flex-col justify-center"
      >
        <div class="text-2xl font-bold md:text-3xl mx-auto">Delete Product</div>
        <div class="font-medium text-lg md:font-semibold md:text-xl mx-auto">
          Are you sure you want to delete this product?
        </div>

        <div class="mx-auto flex justify-center">
          <button
            id="cbutton"
            class="px-8 py-2 mx-1.5 my-1 rounded-lg focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
            @click="isShow = !isShow"
          >
            Cancel
          </button>
          <button
            id="dbutton"
            class="px-8 py-2 mx-1.5 my-1 rounded-lg focus:shadow-outline focus:outline-none focus:ring-2 ring-offset-current ring-offset-2"
            @click="deleteAlbum"
          >
            Delete
          </button>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "Preview",
  props: ["albumId"],
  data() {
    return {
      albums: [],
      previewImage: null,
      artists: "",
      albumName: "",
      coverimage: "",
      description: "",
      albumtype: "",
      albumVersion: "",
      date: "",
      price: "",
      img: "",
      isShow: false,
    };
  },
  methods: {
    edit() {
      this.$router.push({ name: "Edit", params: { albumId: this.albumId } });
    },
    async deleteAlbum() {
      await fetch("http://168.63.232.208/backend/album/" + this.albumId, {
        method: "DELETE",
      });
      this.$router.push({ name: "Product" });
    },
  },
  async mounted() {
    const response = await fetch(
      "http://168.63.232.208/backend/album/" + this.albumId
    );
    const data = await response.json();
    this.albums = await data;
    this.artists = this.albums.artists.artistName;
    this.albumName = this.albums.albumName;
    this.description = this.albums.albumDescription;
    this.albumtype = this.albums.albumTypes.albumType;
    this.albumVersion = this.albums.albumVersions;
    this.price = this.albums.albumPrice;
    this.date = this.albums.albumReleaseDate;
    this.img =
      "http://168.63.232.208/backend/image/" + this.albums.albumCoverImage;
  },
};
</script>

<style>
#bbutton {
  background-color: #ffd600;
  color: #ffffff;
}
#dbutton {
  background-color: #e24d3a;
  color: #ffffff;
}
#cbutton {
  background-color: #cfcfcf;
  color: #ffffff;
}
#dbutton:hover {
  background-color: #c03927;
  color: #ffffff;
}
#cbutton:hover {
  background-color: #bbbbbb;
  color: #ffffff;
}
#bbutton:hover {
  background-color: #e4c000;
  color: #ffffff;
}
.img {
  width: 250px;
  height: 250px;
}
.img {
  width: 350px;
  height: 350px;
}
.img {
  width: 250px;
  height: 250px;
}
@media (min-width: 1650px) {
  .title {
    margin-left: 160px;
  }
}
#confirm {
  position: fixed; /* Stay in place */
  z-index: 11; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  backdrop-filter: blur(6px);
}
</style>
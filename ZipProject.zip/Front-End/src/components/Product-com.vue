<template>
  <div>
    <div class="font-bold text-5xl px-6" id="title">Product</div>

    <div class="justify-center flex-col" v-if="iuAlbum.length > 0">
      <div class="sticky top-20"><ArtistBanner> IU </ArtistBanner></div>
      <div class="grid sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 md:gap-2 justify-items-center mb-20  w-full">
        <div v-for="album in iuAlbum" :key="album" >
          <AlbumObject :album="album" />
        </div>
      </div>
    </div>
    <div class="justify-center flex-col" v-if="izoneAlbum.length > 0">
      <div class="sticky top-20"><ArtistBanner> IZ*ONE </ArtistBanner></div>
      <div class="grid sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 md:gap-2 justify-items-center mb-20  w-full">
        <div v-for="album in izoneAlbum" :key="album">
          <AlbumObject :album="album" />
        </div>
      </div>
    </div>
    <div class="justify-center flex-col" v-if="btsAlbum.length > 0">
      <div class="sticky top-20"><ArtistBanner> BTS </ArtistBanner></div>
      <div class="grid sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5 md:gap-2 justify-items-center mb-20  w-full">
        <div v-for="album in btsAlbum" :key="album">
          <AlbumObject :album="album" />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import AlbumObject from "../components/Album-com.vue";
import ArtistBanner from "../components/Artist-com.vue";

export default {
  name: "ProductLine",
  components: {
    AlbumObject,
    ArtistBanner
  },
  data() {
    return {
      albums: [],
      izoneAlbum: [],
      btsAlbum: [],
      iuAlbum: []
    };
  },

  methods: {},

  async mounted() {
    const res = await fetch("http://168.63.232.208/backend/album");
    const data = await res.json();
    this.albums = data;
    this.iuAlbum = this.albums.filter(album => {
      return album.artists.artistName == "IU";
    });
    this.izoneAlbum = this.albums.filter(album => {
      return album.artists.artistName == "IZ*ONE";
    });
    this.btsAlbum = this.albums.filter(album => {
      return album.artists.artistName == "BTS";
    });
  }
};
</script>

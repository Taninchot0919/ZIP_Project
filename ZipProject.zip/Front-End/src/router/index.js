import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Product from '../views/Product.vue'
import Add from '../views/Add.vue'
import Edit from '../views/Edit.vue'
import Founder from '../views/Founder.vue'
import Preview from '../views/Preview.vue'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  }, {
    path: '/product',
    name: 'Product',
    component: Product,
    props: true
  }, {
    path: '/founder',
    name: 'Founder',
    component: Founder
  }, {
    path: '/add',
    name: 'Add',
    component: Add
  }, {
    path: '/edit/:albumId',
    name: 'Edit',
    component: Edit,
    props: true
  }, {
    path: '/preview/:albumId',
    name: 'Preview',
    component: Preview,
    props: true
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})

export default router

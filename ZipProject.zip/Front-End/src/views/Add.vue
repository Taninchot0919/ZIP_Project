<template>
    <AddProduct />
</template>

<script>
import AddProduct from "../components/Add-com.vue";

export default {
  name: "Add",
  components: {
    AddProduct,
  },
};
</script>
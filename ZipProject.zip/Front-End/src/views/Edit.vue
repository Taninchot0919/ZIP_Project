<template>
  <EditProduct :albumId="albumId" />
</template>
<script>
import EditProduct from "../components/Edit-com.vue";

export default {
  name: "Edit",
  props: ["albumId"],
  components: {
    EditProduct,
  },
  mounted() {
  },
};
</script>

<template>
    <Founders />
</template>
<script>
import Founders from "../components/Founder-com.vue";

export default {
  name: "Founder",
  components: {
    Founders,
  },
};
</script>

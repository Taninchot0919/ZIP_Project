<template>
  <HomeContent />
</template>

<script>
import HomeContent from "../components/Home-com.vue";

export default {
  name: "Home",
  components: {
    HomeContent,
  },
};
</script>

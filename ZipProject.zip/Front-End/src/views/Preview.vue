<template>
  <div>
    <Preview :albumId="albumId" />
  </div>
</template>
<script>
import Preview from "../components/Preview-com.vue";

export default {
  Name: "Preview",
  props: ["albumId"],
  components: {
    Preview,
  },
  mounted() {
  },
};
</script>

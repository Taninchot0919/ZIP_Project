<template>
  <div class="">
    <ProductLine class="-mb-20 mx-auto" />

    <router-link to="Add" class="fixed bottom-5 right-5 hidden md:block">
      <button class="w-auto rounded-lg px-6 py-3 shadow-xl focus:outline-none focus:ring-2 ring-offset-current ring-offset-1" id="addbutton">
        Add Product +
      </button></router-link
    >
    <router-link to="Add" class="fixed bottom-5 right-5 md:hidden">
      <button class="w-12 rounded-lg p-3 shadow-xl focus:outline-none focus:ring-2 ring-offset-current ring-offset-1" id="addbutton">
        +
      </button></router-link
    >
  </div>
</template>
<script>
import ProductLine from "../components/Product-com.vue";

export default {
  name: "Product",
  components: {
    ProductLine,
  },
};
</script>
<style>
#addbutton {
  background-color: #ffd600;
  color: #ffffff;
}
#addbutton:hover {
  background-color: #e4c000;
  color: #ffffff;
}
</style>

module.exports = {
  purge: { content: ['./public/**/*.html', './src/**/*.vue'] },
  darkMode: false, // or 'media' or 'class'
  theme: {
    extend: {
      spacing:{
        '2/5': '40%'
      }
    },
  },
  variants: {
    extend: {},
  },
  plugins: [],
}
